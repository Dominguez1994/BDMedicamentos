//
//  ViewControllerTableViewCell.swift
//  PruebaBDProducto
//
//  Created by Francisco on 4/24/19.
//  Copyright © 2019 Francisco. All rights reserved.
//

import UIKit

class ViewControllerTableViewCell: UITableViewCell

{
    
    @IBOutlet weak var lblNameCon: UILabel!
    @IBOutlet weak var lblCodigo: UILabel!
    @IBOutlet weak var lblColor: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
