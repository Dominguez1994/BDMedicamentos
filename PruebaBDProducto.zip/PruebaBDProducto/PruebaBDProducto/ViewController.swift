//
//  ViewController.swift
//  PruebaBDProducto
//
//  Created by Francisco on 4/24/19.
//  Copyright © 2019 Francisco. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var refer: DatabaseReference!
    
    
    @IBOutlet weak var txtNameMedicamento: UITextField!
    @IBOutlet weak var txtColorMedicamento: UITextField!
    
    @IBOutlet weak var txCodigo: UITextField!
    
    @IBOutlet weak var lblMensaje: UILabel!
    
    
    @IBOutlet weak var tblProducto: UITableView!
    
    var productoList = [ProductoModell]()
    
    //caja
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let produc = productoList[indexPath.row]
        let alert = UIAlertController(title: produc.name, message: "Nuevos Datos", preferredStyle:.alert)
        
        let editAction = UIAlertAction(title: "Editar", style:.default){(_) in
            let id = produc.id
            let name = alert.textFields?[0].text
            let codigo = alert.textFields?[1].text
            let color = alert.textFields?[2].text
            
            self.editProduct(id: id!, name: name!, codigo: codigo!, color: color!)
        
        }
        
        
        let deleteAction = UIAlertAction(title: "Eliminar", style:.default){(_) in
            self.deleteProducto(id: produc.id!)
            
        }
        
        alert.addTextField{(textField) in
            textField.text = produc.name
        }
        alert.addTextField{(textField) in
            textField.text = produc.codigo
        }
        alert.addTextField{(textField) in
            textField.text = produc.color
        }
        
        alert.addAction(editAction)
        alert.addAction(deleteAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    
    func editProduct(id: String, name: String, codigo: String, color: String){
        let produc = [
            "id": id,
            "prodectName": name,
            "productCodigo": codigo,
            "productColor": color
        
        ]
        refer.child(id).setValue(produc)
        lblMensaje.text = "Producto Editado"
        
    }
    
    func deleteProducto(id: String){
        refer.child(id).setValue(nil)
        
    }
    
    
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productoList.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerTableViewCell
        
        let product: ProductoModell
        product = productoList[indexPath.row]
        
        cell.lblNameCon.text = product.name
        cell.lblCodigo.text = product.codigo
        cell.lblColor.text = product.color
        
        return cell
    }
    
    //minuto
    
    
    
    @IBAction func btnGuardar(_ sender: UIButton) {
        addProducto()
        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        FirebaseApp.configure()
        refer  = Database.database().reference().child("producto")
        
        refer.observe(DataEventType.value, with: {(snapshot) in
            if snapshot.childrenCount>0{
                self.productoList.removeAll()
                
                for producto in snapshot.children.allObjects as![DataSnapshot]{
                    let productoObject = producto.value as? [String: AnyObject]
                    let productoName = productoObject?["productoName"]
                    let productoCodigo = productoObject?["productoCodigo"]
                    let productoColor = productoObject?["productoColor"]
                    let productoId = productoObject?["id"]
                    
                    let product = ProductoModell(id: productoId as! String?, name: productoName as! String?, codigo: productoCodigo as! String?, color: productoColor as! String?)
                    
                    self.productoList.append(product)
                    
                }
                
                self.tblProducto.reloadData()
                
            }
            
        })
    }
    
    func addProducto(){
        let key = refer.childByAutoId().key
        
        let medicamento = ["id": key,
                           "nombreProducto": txtNameMedicamento.text! as String,
                           "colorProducto": txtColorMedicamento.text! as String,
                           "codigoProducto": txCodigo.text! as String
        
                            ]
        
        refer.child(key!).setValue(medicamento)
        lblMensaje.text = "Guardado"
        
    }


}

