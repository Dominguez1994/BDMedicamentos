//
//  ProductoModel.swift
//  PruebaBDProducto
//
//  Created by Francisco on 4/24/19.
//  Copyright © 2019 Francisco. All rights reserved.
//

class ProductoModell{
    var id: String?
    var name: String?
    var codigo: String?
    var color: String?
    
    
    init(id:String?, name: String?, codigo: String?, color: String?){
        
        self.id = id
        self.name = name
        self.codigo = codigo
        self.color = color 
    }
    
}
